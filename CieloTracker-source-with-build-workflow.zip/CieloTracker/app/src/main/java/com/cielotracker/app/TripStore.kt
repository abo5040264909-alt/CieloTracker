package com.cielotracker.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small local-only store for the first prototype. */
object TripStore {
    private const val PREFS = "cielo_tracker_local"
    private const val KEY_POINTS = "points"
    private const val KEY_STOPS = "stops"
    private const val KEY_LAST_OIL_KM = "last_oil_km"
    private const val KEY_OIL_INTERVAL = "oil_interval_km"
    private const val KEY_TOTAL_KM = "total_km"

    fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun points(c: Context): JSONArray = runCatching { JSONArray(prefs(c).getString(KEY_POINTS, "[]")) }.getOrElse { JSONArray() }
    fun stops(c: Context): JSONArray = runCatching { JSONArray(prefs(c).getString(KEY_STOPS, "[]")) }.getOrElse { JSONArray() }
    fun savePoint(c: Context, point: JSONObject) {
        val a = points(c); a.put(point)
        // Keep the prototype bounded; export/archive can be added in a later version.
        while (a.length() > 20000) a.remove(0)
        prefs(c).edit().putString(KEY_POINTS, a.toString()).apply()
    }
    fun saveStop(c: Context, stop: JSONObject) {
        val a = stops(c); a.put(stop)
        while (a.length() > 2000) a.remove(0)
        prefs(c).edit().putString(KEY_STOPS, a.toString()).apply()
    }
    fun oilInterval(c: Context) = prefs(c).getInt(KEY_OIL_INTERVAL, 5000)
    fun lastOilKm(c: Context) = prefs(c).getFloat(KEY_LAST_OIL_KM, 0f).toDouble()
    fun setOil(c: Context, odometerKm: Double, intervalKm: Int) {
        prefs(c).edit().putFloat(KEY_LAST_OIL_KM, odometerKm.toFloat()).putInt(KEY_OIL_INTERVAL, intervalKm).apply()
    }
    fun totalKm(c: Context) = prefs(c).getFloat(KEY_TOTAL_KM, 0f).toDouble()
    fun addKm(c: Context, km: Double) {
        if (km > 0 && km < 1.0) prefs(c).edit().putFloat(KEY_TOTAL_KM, (totalKm(c) + km).toFloat()).apply()
    }
    fun remainingOilKm(c: Context): Double = oilInterval(c) - (totalKm(c) - lastOilKm(c))
}
