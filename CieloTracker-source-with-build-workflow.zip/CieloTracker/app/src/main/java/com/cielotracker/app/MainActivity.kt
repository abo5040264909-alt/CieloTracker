package com.cielotracker.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var summary: TextView
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) startTracking()
        else Toast.makeText(this, "برای ثبت مسیر باید اجازه مکان را بدهی.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 12); setBackgroundColor(Color.rgb(16, 24, 32)) }
        val title = TextView(this).apply { text = "CIELO TRACKER"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; setPadding(2, 4, 2, 12) }
        summary = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE); setPadding(4, 8, 4, 12) }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "شروع ثبت"; setOnClickListener { requestOrStart() } }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply { text = "ثبت تعویض روغن"; setOnClickListener { showOilDialog() } }, LinearLayout.LayoutParams(0, -2, 1f))
        map = MapView(this).apply { setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true); controller.setZoom(12.0); controller.setCenter(GeoPoint(35.6892, 51.3890)) }
        root.addView(title); root.addView(summary); root.addView(buttons)
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshSummary(); drawHistory()
    }

    private fun requestOrStart() {
        val wanted = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (wanted.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) permissions.launch(wanted.toTypedArray()) else startTracking()
    }
    private fun startTracking() {
        val i = Intent(this, TrackingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, i) else startService(i)
        Toast.makeText(this, "ثبت مسیر درخواست شد. برای ثبت در پس‌زمینه، مجوز مکان پس‌زمینه را هم از تنظیمات فعال کن.", Toast.LENGTH_LONG).show()
    }
    private fun showOilDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 8) }
        val odo = android.widget.EditText(this).apply { hint = "کیلومتر فعلی خودرو"; inputType = 8192 }
        val interval = android.widget.EditText(this).apply { hint = "فاصله سرویس (مثلاً 5000)"; setText(TripStore.oilInterval(this@MainActivity).toString()); inputType = 2 }
        layout.addView(odo); layout.addView(interval)
        android.app.AlertDialog.Builder(this).setTitle("ثبت تعویض روغن").setView(layout)
            .setPositiveButton("ذخیره") { _, _ ->
                val km = odo.text.toString().toDoubleOrNull(); val iv = interval.text.toString().toIntOrNull()
                if (km != null && iv != null && km >= 0 && iv > 0) { TripStore.setOil(this, km, iv); refreshSummary() }
                else Toast.makeText(this, "مقادیر معتبر وارد کن.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("انصراف", null).show()
    }
    private fun refreshSummary() {
        val p = TripStore.points(this)
        val s = TripStore.stops(this)
        val today = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        var todaySegments = 0; var todayKm = 0.0
        for (i in 0 until p.length()) {
            val o = p.optJSONObject(i) ?: continue
            if (SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(o.optLong("end"))) == today) { todaySegments++; todayKm += o.optDouble("meters") / 1000.0 }
        }
        val remaining = TripStore.remainingOilKm(this)
        summary.text = "امروز · $todaySegments قطعه مسیر ثبت‌شده · ${"%.1f".format(todayKm)} کیلومتر\nنقاط/رویدادهای ذخیره‌شده: ${s.length()}\n" +
            if (TripStore.lastOilKm(this) <= 0) "برای یادآوری روغن، «ثبت تعویض روغن» را بزن." else if (remaining <= 0) "⚠ موعد تعویض روغن رسیده است" else "تا سرویس بعدی حدود ${remaining.toInt()} کیلومتر"
    }
    private fun drawHistory() {
        map.overlays.clear()
        val points = TripStore.points(this)
        val bounds = mutableListOf<GeoPoint>()
        for (i in 0 until points.length()) {
            val o: JSONObject = points.optJSONObject(i) ?: continue
            val a = GeoPoint(o.optDouble("lat1"), o.optDouble("lon1")); val b = GeoPoint(o.optDouble("lat2"), o.optDouble("lon2"))
            val line = Polyline().apply { setPoints(listOf(a, b)); outlinePaint.strokeWidth = 12f; outlinePaint.color = runCatching { Color.parseColor(o.optString("color", "#22C55E")) }.getOrDefault(Color.GREEN) }
            map.overlays.add(line); bounds.add(a); bounds.add(b)
        }
        val stops = TripStore.stops(this)
        for (i in 0 until stops.length()) {
            val o = stops.optJSONObject(i) ?: continue
            if (!o.has("lat") || !o.has("lon")) continue
            val marker = Marker(map); marker.position = GeoPoint(o.optDouble("lat"), o.optDouble("lon")); marker.title = "توقف"
            marker.snippet = "ورود: ${Date(o.optLong("arrival"))}\nخروج: ${Date(o.optLong("departure"))}"
            map.overlays.add(marker); bounds.add(marker.position)
        }
        if (bounds.isNotEmpty()) { map.controller.setCenter(bounds.last()); map.controller.setZoom(14.0) }
        map.invalidate()
    }
    override fun onResume() { super.onResume(); map.onResume(); refreshSummary(); drawHistory() }
    override fun onPause() { map.onPause(); super.onPause() }
    override fun onDestroy() { map.onDetach(); super.onDestroy() }
}
