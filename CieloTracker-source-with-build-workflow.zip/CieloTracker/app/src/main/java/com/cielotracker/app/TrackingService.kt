package com.cielotracker.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import kotlin.math.max

class TrackingService : Service(), LocationListener {
    private lateinit var locationManager: LocationManager
    private var lastLocation: Location? = null
    private var segmentStart: Location? = null
    private var segmentDistance = 0.0
    private var segmentStartedAt = 0L
    private var stopStartedAt = 0L
    private var stopStartLocation: Location? = null
    private var stopSaved = false
    private var tripActive = false
    private var tripStartedAt = 0L
    private var tripDistance = 0.0
    private var lastOilNoticeAt = 0L

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        createChannel()
        startForeground(42, notification("ثبت مسیر فعال است"))
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try { locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 0f, this, Looper.getMainLooper()) } catch (_: Exception) { }
            try { locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 0f, this, Looper.getMainLooper()) } catch (_: Exception) { }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onLocationChanged(location: Location) {
        if (!location.hasAccuracy() || location.accuracy > 50f) return
        val now = location.time
        val previous = lastLocation
        if (previous == null) {
            lastLocation = location
            segmentStart = location
            segmentStartedAt = now
            return
        }
        val dt = max(1L, now - previous.time)
        val distance = previous.distanceTo(location).toDouble()
        // Reject implausible GPS jumps (above 180 km/h or a single enormous jump).
        // Small movements are handled below as possible stationary drift, not discarded,
        // otherwise the stop detector would never accumulate a full 10/60 minutes.
        val speed = if (location.hasSpeed()) location.speed * 3.6 else distance * 3600.0 / dt
        if (distance > 250 || speed > 180) {
            lastLocation = location
            return
        }

        if (distance < 5 && speed < 4.0) {
            if (stopStartedAt == 0L) { stopStartedAt = previous.time; stopStartLocation = previous; stopSaved = false }
            val stopDuration = now - stopStartedAt
            if (!stopSaved && stopDuration > 10 * 60 * 1000L) saveStop(stopStartLocation ?: previous, stopStartedAt, now, false)
            if (stopDuration > 60 * 60 * 1000L && tripActive) finishTrip(stopStartedAt)
        } else {
            if (stopStartedAt != 0L) {
                if (!stopSaved && now - stopStartedAt > 10 * 60 * 1000L) saveStop(stopStartLocation ?: previous, stopStartedAt, now, true)
                if (now - stopStartedAt > 60 * 60 * 1000L) finishTrip(stopStartedAt)
                stopStartedAt = 0L; stopStartLocation = null; stopSaved = false
            }
            if (!tripActive) { tripActive = true; tripStartedAt = previous.time; tripDistance = 0.0 }
            tripDistance += distance
            TripStore.addKm(this, distance / 1000.0)
            val segStart = segmentStart ?: previous.also { segmentStart = it; segmentStartedAt = it.time }
            segmentDistance += distance
            if (segmentDistance >= 200.0) {
                val seconds = max(1.0, (now - segmentStartedAt) / 1000.0)
                val averageKmh = (segmentDistance / seconds) * 3.6
                val p = JSONObject().put("lat1", segStart.latitude).put("lon1", segStart.longitude)
                    .put("lat2", location.latitude).put("lon2", location.longitude)
                    .put("start", segmentStartedAt).put("end", now).put("meters", segmentDistance)
                    .put("speedKmh", averageKmh).put("color", speedColor(averageKmh)).put("tripStart", tripStartedAt)
                TripStore.savePoint(this, p)
                segmentStart = location; segmentStartedAt = now; segmentDistance = 0.0
            }
            updateNotification("سفر فعال · ${"%.1f".format(tripDistance / 1000)} کیلومتر")
            checkOilReminder()
        }
        lastLocation = location
    }

    private fun speedColor(speed: Double): String = when {
        speed < 30 -> "#22C55E"
        speed < 60 -> "#EAB308"
        speed < 90 -> "#F97316"
        else -> "#EF4444"
    }

    private fun saveStop(loc: Location, start: Long, end: Long, closed: Boolean) {
        if (stopSaved) return
        TripStore.saveStop(this, JSONObject().put("lat", loc.latitude).put("lon", loc.longitude)
            .put("arrival", start).put("departure", end).put("durationMs", end - start).put("closed", closed))
        stopSaved = true
    }

    private fun finishTrip(end: Long) {
        if (tripActive) {
            TripStore.saveStop(this, JSONObject().put("event", "trip_end").put("start", tripStartedAt).put("end", end).put("distanceKm", tripDistance / 1000.0))
        }
        tripActive = false; tripDistance = 0.0; segmentDistance = 0.0; segmentStart = lastLocation; segmentStartedAt = end
    }

    private fun checkOilReminder() {
        val remaining = TripStore.remainingOilKm(this)
        val now = System.currentTimeMillis()
        if (remaining <= 300 && now - lastOilNoticeAt > 6 * 60 * 60 * 1000L) {
            lastOilNoticeAt = now
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(43, NotificationCompat.Builder(this, "cielo_tracker")
                .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("یادآوری سرویس Cielo")
                .setContentText(if (remaining <= 0) "موعد تعویض روغن رسیده است" else "حدود ${remaining.toInt()} کیلومتر تا تعویض روغن باقی مانده")
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build())
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("cielo_tracker", "Cielo Tracker", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "cielo_tracker").setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Cielo Tracker").setContentText(text).setContentIntent(pi).setOngoing(true).build()
    }
    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(42, notification(text))
    }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { updateNotification("GPS در دسترس نیست") }
    override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { runCatching { locationManager.removeUpdates(this) }; super.onDestroy() }
}
